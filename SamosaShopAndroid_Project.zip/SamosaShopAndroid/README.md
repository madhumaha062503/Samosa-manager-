# Samosa Shop Manager (Android)

Android WebView wrapper for the Samosa Shop Manager billing/stock app. Default samosa price is ₹6. Includes billing, automatic stock deduction, sales history/CSV export, expenses, estimated daily profit, bill share/copy and browser print support.

## Build an APK with Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder (`SamosaShopAndroid`) as an existing project.
3. Let Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

## Build an APK on GitHub (no local Android SDK needed)
1. Create a GitHub repository and upload the contents of this folder.
2. Open **Actions**, select **Build Android APK**, then click **Run workflow**.
3. When it finishes, open the workflow run and download the `samosa-shop-manager-apk` artifact. Extract it to get `app-debug.apk`.

## Notes
- This is a basic offline app; records are saved locally on the phone and are not synced to the cloud.
- Export the sales CSV regularly. Uninstalling or clearing app data can remove saved records.
- Debug APK is for personal installation/testing. A Play Store release needs a signed release build.
